import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:english_companion_beginner/main.dart';

void main() {
  testWidgets('skill chip renders its Persian label', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(body: SkillChip(icon: Icons.chat, label: 'مکالمه')),
      ),
    );
    expect(find.text('مکالمه'), findsOneWidget);
  });
}
