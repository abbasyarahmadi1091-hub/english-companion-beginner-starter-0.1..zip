import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = LearningStore();
  await store.open();
  runApp(EnglishCompanionApp(store: store));
}

class LearningStore {
  Database? _db;

  Future<void> open() async {
    final dbPath = await getDatabasesPath();
    _db = await openDatabase(
      p.join(dbPath, 'english_companion_beginner.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE lesson_progress(
            lesson_id TEXT PRIMARY KEY,
            completed INTEGER NOT NULL DEFAULT 0,
            score INTEGER NOT NULL DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE TABLE saved_words(
            word TEXT PRIMARY KEY,
            meaning TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
        await db.insert('lesson_progress', {
          'lesson_id': 'pre_a1_greetings_01',
          'completed': 0,
          'score': 0,
        });
      },
    );
  }

  Future<int> completedLessons() async {
    final rows = await _db!.rawQuery(
      'SELECT COUNT(*) AS total FROM lesson_progress WHERE completed = 1',
    );
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  Future<void> completeFirstLesson() async {
    await _db!.update(
      'lesson_progress',
      {'completed': 1, 'score': 100},
      where: 'lesson_id = ?',
      whereArgs: ['pre_a1_greetings_01'],
    );
  }

  Future<void> saveWord(String word, String meaning) async {
    await _db!.insert(
      'saved_words',
      {
        'word': word,
        'meaning': meaning,
        'created_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, Object?>>> words() async =>
      _db!.query('saved_words', orderBy: 'created_at DESC');
}

class EnglishCompanionApp extends StatelessWidget {
  const EnglishCompanionApp({super.key, required this.store});
  final LearningStore store;

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF172B4D);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'همراه انگلیسی',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F9FC),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3478C8)),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: MainShell(store: store),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.store});
  final LearningStore store;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  late final pages = [
    HomePage(store: widget.store, onLearn: () => setState(() => index = 1)),
    LearningPage(store: widget.store),
    PracticePage(store: widget.store),
    EmmaPage(store: widget.store),
    ProfilePage(store: widget.store),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'یادگیری'),
          NavigationDestination(icon: Icon(Icons.fitness_center_outlined), selectedIcon: Icon(Icons.fitness_center), label: 'تمرین'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'اِما'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'پروفایل'),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.store, required this.onLearn});
  final LearningStore store;
  final VoidCallback onLearn;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int completed = 0;

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    final value = await widget.store.completedLessons();
    if (mounted) setState(() => completed = value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('همراه انگلیسی'), actions: const [
        Padding(padding: EdgeInsetsDirectional.only(end: 16), child: Icon(Icons.offline_bolt))
      ]),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('سلام! خوش اومدی 🌱', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('قدم‌به‌قدم انگلیسی یاد بگیر؛ حتی بدون اینترنت.'),
          const SizedBox(height: 22),
          Card(
            color: const Color(0xFF172B4D),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('مسیر یادگیری تو', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 8),
                const Text('سطح مبتدی · Pre-A1', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Text('$completed درس از ۱ درس نمونه تکمیل شده', style: const TextStyle(color: Colors.white)),
                const SizedBox(height: 14),
                FilledButton(
                  onPressed: widget.onLearn,
                  style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF172B4D)),
                  child: const Text('ادامه یادگیری'),
                )
              ]),
            ),
          ),
          const SizedBox(height: 18),
          const Text('مهارت‌های تو', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          const Wrap(spacing: 8, runSpacing: 8, children: [
            SkillChip(icon: Icons.chat, label: 'مکالمه'),
            SkillChip(icon: Icons.headphones, label: 'شنیداری'),
            SkillChip(icon: Icons.menu_book, label: 'خواندن'),
            SkillChip(icon: Icons.edit, label: 'نوشتن'),
            SkillChip(icon: Icons.translate, label: 'واژگان'),
            SkillChip(icon: Icons.rule, label: 'گرامر'),
          ]),
          const SizedBox(height: 18),
          const Card(child: ListTile(leading: Icon(Icons.wifi_off, color: Colors.green), title: Text('آماده یادگیری آفلاین'), subtitle: Text('اطلاعات آموزشی روی همین دستگاه نگهداری می‌شود.'))),
        ],
      ),
    );
  }
}

class SkillChip extends StatelessWidget {
  const SkillChip({super.key, required this.icon, required this.label});
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) => Chip(avatar: Icon(icon, size: 18), label: Text(label), backgroundColor: Colors.white);
}

class LearningPage extends StatelessWidget {
  const LearningPage({super.key, required this.store});
  final LearningStore store;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('یادگیری')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Pre-A1 · شروع از صفر', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      const LinearProgressIndicator(value: 0),
      const SizedBox(height: 18),
      const Text('دوره اول: آشنایی و شروع مکالمه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      LessonCard(store: store, title: 'سلام و احوال‌پرسی', subtitle: 'Hello · Hi · How are you?', duration: '۵ دقیقه'),
      const LessonCard(store: null, title: 'معرفی خود', subtitle: 'My name is…', duration: '۱۰ دقیقه', locked: true),
      const LessonCard(store: null, title: 'عبارت‌های روزمره', subtitle: 'Please · Thank you · Sorry', duration: '۱۰ دقیقه', locked: true),
    ]),
  );
}

class LessonCard extends StatelessWidget {
  const LessonCard({super.key, required this.store, required this.title, required this.subtitle, required this.duration, this.locked = false});
  final LearningStore? store;
  final String title, subtitle, duration;
  final bool locked;

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: CircleAvatar(child: Icon(locked ? Icons.lock_outline : Icons.play_arrow)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text('$subtitle\n$duration'),
      isThreeLine: true,
      trailing: const Icon(Icons.chevron_left),
      onTap: locked ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonPage(store: store!))),
    ),
  );
}

class LessonPage extends StatefulWidget {
  const LessonPage({super.key, required this.store});
  final LearningStore store;
  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  String? selectedAnswer;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('درس: سلام و احوال‌پرسی')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('هدف درس', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('در پایان این درس می‌توانی به انگلیسی سلام کنی و حال دیگران را بپرسی.'),
      const SizedBox(height: 20),
      const Text('عبارت‌های مهم', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const VocabularyTile(word: 'Hello', meaning: 'سلام'),
      const VocabularyTile(word: 'Hi', meaning: 'سلام (خودمانی)'),
      const VocabularyTile(word: 'How are you?', meaning: 'حالت چطوره؟'),
      const VocabularyTile(word: 'I am fine.', meaning: 'من خوبم.'),
      const SizedBox(height: 20),
      const Text('مکالمه نمونه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Emma: Hello!'),
        Text('You: Hi!'),
        SizedBox(height: 8),
        Text('Emma: How are you?'),
        Text('You: I am fine, thank you.'),
      ]))),
      const SizedBox(height: 18),
      const Text('تمرین کوتاه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const Text('معنی عبارت «How are you?» چیست؟'),
      const SizedBox(height: 8),
      ...['اسمت چیست؟', 'حالت چطوره؟', 'کجا زندگی می‌کنی؟'].map((answer) => RadioListTile<String>(
        value: answer, groupValue: selectedAnswer,
        onChanged: (value) => setState(() => selectedAnswer = value), title: Text(answer),
      )),
      if (selectedAnswer != null)
        Text(
          selectedAnswer == 'حالت چطوره؟' ? 'آفرین! پاسخ درست است.' : 'یک بار دیگر فکر کن؛ معنی سؤال درباره حال شخص است.',
          style: TextStyle(
            color: selectedAnswer == 'حالت چطوره؟' ? Colors.green : Colors.deepOrange,
            fontWeight: FontWeight.bold,
          ),
        ),
      const SizedBox(height: 16),
      FilledButton(
        onPressed: () async {
          await widget.store.completeFirstLesson();
          if (!context.mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پیشرفت درس روی دستگاه ذخیره شد.')));
          Navigator.pop(context);
        },
        child: const Text('ثبت تکمیل درس نمونه'),
      )
    ]),
  );
}

class VocabularyTile extends StatelessWidget {
  const VocabularyTile({super.key, required this.word, required this.meaning});
  final String word, meaning;
  @override
  Widget build(BuildContext context) => Card(child: ListTile(title: Text(word, textDirection: TextDirection.ltr), subtitle: Text(meaning), trailing: const Icon(Icons.volume_up_outlined)));
}

class PracticePage extends StatelessWidget {
  const PracticePage({super.key, required this.store});
  final LearningStore store;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تمرین و مرور')),
    body: ListView(padding: const EdgeInsets.all(18), children: const [
      Text('تمرین‌های امروز', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 12),
      Card(child: ListTile(leading: Icon(Icons.style), title: Text('مرور واژگان'), subtitle: Text('واژه‌هایی که ذخیره کرده‌ای را مرور کن.'))),
      Card(child: ListTile(leading: Icon(Icons.hearing), title: Text('تمرین شنیداری'), subtitle: Text('در نسخه‌های بعدی با فایل‌های صوتی آفلاین تکمیل می‌شود.'))),
      Card(child: ListTile(leading: Icon(Icons.record_voice_over), title: Text('تمرین تلفظ'), subtitle: Text('اتصال به موتور گفتار پس از آزمون فنی اضافه می‌شود.'))),
    ]),
  );
}

class EmmaPage extends StatelessWidget {
  const EmmaPage({super.key, required this.store});
  final LearningStore store;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('هم‌صحبت با اِما')),
    body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const CircleAvatar(radius: 42, child: Icon(Icons.face_3, size: 48)),
      const SizedBox(height: 16),
      const Text('سلام! من اِما هستم 😊', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('در این نمونه، مکالمه نمایشی آماده است. مکالمه صوتی واقعی پس از انتخاب و آزمایش موتور گفتار اضافه می‌شود.', textAlign: TextAlign.center),
      const SizedBox(height: 16),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Emma: Hello! What is your name?', textDirection: TextDirection.ltr))),
      const Text('Emma: سلام! اسمت چیه؟'),
    ]))),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key, required this.store});
  final LearningStore store;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('پروفایل و تنظیمات')),
    body: ListView(children: const [
      ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('کاربر مهمان'), subtitle: Text('اطلاعات فقط روی همین دستگاه ذخیره می‌شود.')),
      Divider(),
      ListTile(leading: Icon(Icons.volume_up_outlined), title: Text('تنظیمات صدا'), subtitle: Text('در نسخه بعدی تکمیل می‌شود.')),
      ListTile(leading: Icon(Icons.dark_mode_outlined), title: Text('حالت تاریک')),
      ListTile(leading: Icon(Icons.backup_outlined), title: Text('پشتیبان‌گیری و انتقال اطلاعات')),
      ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('حریم خصوصی')),
      ListTile(leading: Icon(Icons.info_outline), title: Text('درباره همراه انگلیسی'), subtitle: Text('نسخه نمونه فنی 0.1.0')),
    ]),
  );
}
